// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:petapp/enums/order_option.dart';
import 'package:petapp/enums/sort_option.dart';
import 'package:petapp/models/offer.dart';
import 'package:petapp/services/api_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:intl/intl.dart';

class OffersScreen extends StatefulWidget {
  const OffersScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _OffersScreenState createState() => _OffersScreenState();
}

class _OffersScreenState extends State<OffersScreen>
    with AutomaticKeepAliveClientMixin {
  final ApiService _apiService = ApiService();
  final List<Offer> _offers = [];
  bool _isLoading = false;
  int _currentPage = 1;
  final ScrollController _scrollController = ScrollController();
  bool _isEndOfList = false;

  @override
  void initState() {
    super.initState();
    _fetchOffers();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        _fetchMoreOffers();
      }
    });
  }

  void _fetchOffers() async {
    setState(() {
      _isLoading = true;
      _offers.clear();
      _currentPage = 1;
      _isEndOfList = false;
    });
    try {
      List<Offer> offers = await _apiService.getOffers(page: _currentPage);
      setState(() {
        _offers.addAll(offers);
      });
      _checkIfMoreDataNeeded();
    } catch (e) {
      //Fluttertoast.showToast(msg: 'Error fetching offers: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _fetchMoreOffers() async {
    if (!_isLoading && !_isEndOfList) {
      setState(() {
        _isLoading = true;
      });
      _currentPage++;
      try {
        List<Offer> moreOffers =
            await _apiService.getOffers(page: _currentPage);
        if (moreOffers.isEmpty) {
          setState(() {
            _isEndOfList = true; // No more data is available
            _currentPage--; // Decrement the page number as no more pages are available
          });
        } else {
          setState(() {
            _offers.addAll(moreOffers);
          });
        }
      } catch (e) {
        // Fluttertoast.showToast(
        //   msg: 'Error fetching more offers: $e',
        //   toastLength: Toast.LENGTH_SHORT,
        //   gravity: ToastGravity.BOTTOM,
        //   timeInSecForIosWeb: 1,
        //   backgroundColor: Colors.red,
        //   textColor: Colors.white,
        //   fontSize: 16.0,
        // );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _refreshOffers() async {
    setState(() {
      _currentPage = 1; // Reset to the first page
      _isEndOfList = false; // Reset the end of list flag
    });
    try {
      List<Offer> newOffers = await _apiService.getOffers(page: _currentPage);
      setState(() {
        _offers.clear();
        _offers.addAll(newOffers);
      });
    } catch (e) {
      // Fluttertoast.showToast(
      //   msg: 'Error refreshing offers:$e',
      //   toastLength: Toast.LENGTH_SHORT,
      //   gravity: ToastGravity.BOTTOM,
      //   timeInSecForIosWeb: 1,
      //   backgroundColor: Colors.red,
      //   textColor: Colors.white,
      //   fontSize: 16.0,
      // );
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin
    return Scaffold(
      appBar: AppBar(
          title: Text(AppLocalizations.of(context)!.navigation_offers),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.search),
              onPressed: () => _showAdvancedSearch(context),
            ),
          ]),
      body: Center(
        child: _isLoading && _offers.isEmpty
            ? const CircularProgressIndicator()
            : RefreshIndicator(
                onRefresh: _refreshOffers,
                child: ListView.builder(
                  itemCount: _offers.length +
                      (_isLoading ? 1 : 0) +
                      1, // Add +1 for extra space
                  controller: _scrollController,
                  itemBuilder: (context, index) {
                    if (index < _offers.length) {
                      return _buildOfferCard(_offers[index]);
                    } else if (_isLoading && index == _offers.length) {
                      return const Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    } else if (index > _offers.length) {
                      // Extra space at the bottom
                      return const SizedBox(
                          height: 50); // Adjust the height as needed
                    } else {
                      return const SizedBox(height: 60); // For other cases
                    }
                  },
                )),
      ),
// Add any additional UI components here
    );
  }

  Widget _buildOfferCard(Offer offer) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(10),
      child: InkWell(
        onTap: () {
          // Action for tapping the whole card
          print("Whole Offer ${offer.title} clicked");
        },
        child: Column(
          children: <Widget>[
            // Image or placeholder
            offer.imageUrl.isNotEmpty
                ? Image.network(
                    offer.imageUrl,
                    fit: BoxFit.cover,
                    height: 200, // You can adjust the height
                  )
                : SizedBox(
                    height: 200,
                    child: Card(
                      color: Colors.grey[300], // Placeholder color
                      child: Center(
                        child: Icon(Icons.image,
                            size: 50, color: Colors.grey[600]), // Optional icon
                      ),
                    ),
                  ),

            // Padding for the content below the image
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  // Title and Price
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Flexible(
                        child: Text(
                          offer.title.toUpperCase(),
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                          overflow: TextOverflow
                              .ellipsis, // Prevents text from overflowing
                        ),
                      ),
                      Text(
                        '${offer.price} zł',
                        style: const TextStyle(
                            fontSize: 16,
                            color: Colors.green,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(offer.description),
                  const SizedBox(height: 10),

                  // User profile section
                  InkWell(
                    onTap: () {
                      // Action for tapping the user profile
                      print("User ${offer.user.name} clicked");
                    },
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(
                          15), // Set the border radius here
                      clipBehavior: Clip.hardEdge,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            offer.user.avatarUrl != null
                                ? CircleAvatar(
                                    backgroundImage:
                                        NetworkImage(offer.user.avatarUrl!),
                                    radius: 25,
                                  )
                                : Container(
                                    width: 50,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      color: Colors.grey[300],
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(Icons.person,
                                        size: 30, color: Colors.grey[600]),
                                  ),
                            const SizedBox(width: 10),
                            Text(
                              offer.user.name,
                              style: const TextStyle(fontSize: 16),
                            ),

                            // Rating or Gray Star icon
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: offer.user.averageOfferRating != null
                                  ? Row(
                                      children: [
                                        Icon(Icons.star,
                                            size: 20, color: Colors.amber),
                                        Text(
                                          ' ${offer.user.averageOfferRating!.toStringAsFixed(1)}',
                                          style: const TextStyle(fontSize: 16),
                                        ),
                                      ],
                                    )
                                  : Icon(Icons.star_border,
                                      size: 20, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _checkIfMoreDataNeeded() {
    // Delayed check to allow the list view to build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.position.maxScrollExtent <=
          _scrollController.position.pixels) {
        _fetchMoreOffers();
      }
    });
  }

  void _showAdvancedSearch(BuildContext context) {
    TextEditingController searchController = TextEditingController();
    List<String> ratingOptions = ['2.0', '3.0', '4.0', '4.5'];
    String? selectedRating;
    DateTime? fromDate;
    DateTime? toDate;
    SortOption _selectedSort = SortOption.date;
    OrderOption _selectedOrder = OrderOption.desc;

    Future<void> selectDate(
        BuildContext context, StateSetter setState, bool isFromDate) async {
      final DateTime? picked = await showDatePicker(
        context: context,
        initialDate:
            isFromDate ? fromDate ?? DateTime.now() : toDate ?? DateTime.now(),
        firstDate: DateTime(2020),
        lastDate: DateTime(2027),
      );
      if (picked != null &&
          (isFromDate ? picked != fromDate : picked != toDate)) {
        setState(() {
          // Update using StatefulBuilder's setState
          if (isFromDate) {
            fromDate = picked;
          } else {
            toDate = picked;
          }
        });
      }
    }

    showModalBottomSheet(
      isScrollControlled: true,
      enableDrag: true,
      showDragHandle: true,
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Padding(
              padding: EdgeInsets.all(10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      labelText: 'Search by text',
                      hintText: 'Enter search term',
                      border: OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () => searchController.clear(),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        'Minimum rating:',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                  Wrap(
                    spacing: 8.0,
                    children: List<Widget>.generate(
                      ratingOptions.length,
                      (int index) {
                        return ChoiceChip(
                          label: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(ratingOptions[index]),
                              SizedBox(width: 4), // Space between text and icon
                              Icon(Icons.star_border,
                                  size: 16), // Outlined star icon
                            ],
                          ),
                          selected: selectedRating == ratingOptions[index],
                          onSelected: (bool selected) {
                            setState(() {
                              selectedRating =
                                  selected ? ratingOptions[index] : null;
                            });
                          },
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 15),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('From:', style: TextStyle(fontSize: 16)),
                  ),
                  ListTile(
                    title: Text(fromDate != null
                        ? DateFormat('dd-MM-yyyy').format(fromDate!)
                        : 'Not set'),
                    trailing: Icon(Icons.calendar_today),
                    onTap: () => selectDate(context, setState, true),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('To:', style: TextStyle(fontSize: 16)),
                  ),
                  ListTile(
                    title: Text(toDate != null
                        ? DateFormat('dd-MM-yyyy').format(toDate!)
                        : 'Not set'),
                    trailing: Icon(Icons.calendar_today),
                    onTap: () => selectDate(context, setState, false),
                  ),
                  Divider(),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Sort by:', style: TextStyle(fontSize: 16)),
                  ),
                  SegmentedButton<SortOption>(
                    segments: const <ButtonSegment<SortOption>>[
                      ButtonSegment<SortOption>(
                        value: SortOption.date,
                        label: Text('Date'),
                        icon: Icon(Icons.date_range),
                      ),
                      ButtonSegment<SortOption>(
                        value: SortOption.rating,
                        label: Text('Rating'),
                        icon: Icon(Icons.star),
                      ),
                    ],
                    selected: <SortOption>{_selectedSort},
                    onSelectionChanged: (Set<SortOption> newSelection) {
                      setState(() {
                        _selectedSort = newSelection.first;
                      });
                    },
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Order:', style: TextStyle(fontSize: 16)),
                  ),
                  SegmentedButton<OrderOption>(
                    segments: const <ButtonSegment<OrderOption>>[
                      ButtonSegment<OrderOption>(
                        value: OrderOption.asc,
                        label: Text('Ascending'),
                        icon: Icon(Icons.arrow_upward),
                      ),
                      ButtonSegment<OrderOption>(
                        value: OrderOption.desc,
                        label: Text('Descending'),
                        icon: Icon(Icons.arrow_downward),
                      ),
                    ],
                    selected: <OrderOption>{_selectedOrder},
                    onSelectionChanged: (Set<OrderOption> newSelection) {
                      setState(() {
                        _selectedOrder = newSelection.first;
                      });
                    },
                  ),
                  SizedBox(height: 15),
                  ElevatedButton(
                    child: Text('Search'),
                    onPressed: () {
                      // TODO: Implement your search logic
                      Navigator.pop(context);
                    },
                  ),
                  SizedBox(height: 20),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  bool get wantKeepAlive =>
      true; // Keep state alive for AutomaticKeepAliveClientMixin
}
