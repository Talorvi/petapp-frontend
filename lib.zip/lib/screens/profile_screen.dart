import 'package:flutter/material.dart';
import 'package:petapp/models/user.dart';
import 'package:petapp/widgets/offers_widget.dart';
import 'package:petapp/widgets/reviews_widget.dart';

class ProfileScreen extends StatefulWidget {
  final User user;

  const ProfileScreen({super.key, required this.user});

  @override
  // ignore: library_private_types_in_public_api
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String selectedSegment = 'Offers';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            widget.user.avatarUrl != null
                ? CircleAvatar(
                    backgroundImage: NetworkImage(widget.user.avatarUrl!),
                    radius: 50,
                  )
                : Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      shape: BoxShape.circle,
                    ),
                    child:
                        Icon(Icons.person, size: 30, color: Colors.grey[600]),
                  ),
            const SizedBox(height: 16),
            Text(
              widget.user.name,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            if (widget.user.averageOfferRating != null)
              Text(
                'Average Rating: ${widget.user.averageOfferRating!.toStringAsFixed(1)}',
                style: const TextStyle(fontSize: 18),
              ),
            const SizedBox(height: 12),
            const Divider(),
            const SizedBox(height: 12),
            Center(
              child: SegmentedButton<String>(
                segments: const <ButtonSegment<String>>[
                  ButtonSegment<String>(
                    value: 'Offers',
                    label: Text('Offers'),
                  ),
                  ButtonSegment<String>(
                    value: 'Reviews',
                    label: Text('Reviews'),
                  ),
                ],
                selected: <String>{selectedSegment},
                onSelectionChanged: (Set<String> newSelection) {
                  setState(() {
                    selectedSegment = newSelection.first;
                  });
                },
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: selectedSegment == 'Offers'
                  ? OffersWidget(
                      user: widget.user,
                      isListView: true,
                    )
                  : ReviewsWidget(
                      user: widget.user), // Assuming ReviewsWidget exists
            ),
          ],
        ),
      ),
    );
  }
}
