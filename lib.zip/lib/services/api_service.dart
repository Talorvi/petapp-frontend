import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:petapp/models/offer.dart';
import 'package:petapp/models/user.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;

  ApiService._internal();

  Locale? currentLocale;

  final String baseUrl =
      'http://localhost:8080/api'; // Replace with your API base URL

  // Example: GET request to fetch a list of users
  Future<List<User>> getUsers({int page = 1}) async {
    var url = Uri.parse('$baseUrl/users?page=$page');
    var response = await http.get(url);

    if (response.statusCode == 200) {
      var body = jsonDecode(response.body);
      List<dynamic> usersData = body['data']; // Extract the 'data' list
      List<User> users =
          usersData.map((dynamic item) => User.fromJson(item)).toList();
      return users;
    } else {
      throw Exception("Can't get users. Status code: ${response.statusCode}");
    }
  }

  // Method to register a new user
  Future<Map<String, dynamic>> registerUser(String name, String email,
      String password, String passwordConfirmation) async {
    var url = Uri.parse('$baseUrl/register');
    var response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Accept-Language': _getLocale(),
      },
      body: jsonEncode({
        'name': name,
        'email': email,
        'password': password,
        'password_confirmation': passwordConfirmation,
      }),
    );

    if (response.statusCode == 201) {
      return jsonDecode(response.body);
    } else if (response.statusCode == 422) {
      // Validation error
      final errors = jsonDecode(response.body)['messages'];
      throw errors;
    } else if (response.statusCode == 401) {
      // Unauthorized
      throw 'Unauthorized access';
    } else {
      // Other errors
      throw 'Failed to register user';
    }
  }

  // Method to login a user
  Future<Map<String, dynamic>> loginUser(String email, String password) async {
    var url =
        Uri.parse('$baseUrl/login'); // Adjust the URL as per your API endpoint
    var response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Accept-Language':
            currentLocale?.toLanguageTag() ?? 'en', // Optional for locale
      },
      body: jsonEncode({
        'email': email,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      // Handle successful login
      return jsonDecode(response.body);
    } else if (response.statusCode == 401) {
      // Unauthorized or login failure
      throw 'Invalid credentials'; // Customize this message as needed
    } else {
      // Other errors
      throw 'Failed to log in';
    }
  }

  // Method to fetch the offers
  Future<List<Offer>> getOffers({
    int page = 1,
    String? query,
    String? userId,
    double? minimumRating,
    String? sortBy,
    String? sortDirection,
  }) async {
    // Build the query parameters
    final queryParams = {
      'page': page.toString(),
      if (query != null) 'query': query,
      if (userId != null) 'user_id': userId,
      if (minimumRating != null) 'minimum_rating': minimumRating.toString(),
      if (sortBy != null && ['date', 'rating', 'price'].contains(sortBy))
        'sort_by': sortBy,
      if (sortDirection != null) 'sort_direction': sortDirection,
    };

    var url =
        Uri.parse('$baseUrl/offers').replace(queryParameters: queryParams);
    var response = await http.get(url, headers: {
      'Accept-Language': _getLocale(),
    });

    if (response.statusCode == 200) {
      try {
        var body = jsonDecode(response.body);
        List<dynamic> offersData = body['data']; // Extract the 'data' list
        List<Offer> offers = offersData
            .map((dynamic item) {
              try {
                return Offer.fromJson(item);
              } catch (e) {
                // Handle the error or log it
                print('Error parsing offer: $e');
                return null;
              }
            })
            .where((item) => item != null)
            .cast<Offer>()
            .toList();
        return offers;
      } catch (e) {
        // Handle the error or log it
        throw Exception("Error parsing offers: $e");
      }
    } else {
      throw Exception("Can't get offers. Status code: ${response.statusCode}");
    }
  }

  String _getLocale() {
    return currentLocale?.toLanguageTag() ?? 'en';
  }

  // Add other API interactions here, like POST, PUT, DELETE methods
}
