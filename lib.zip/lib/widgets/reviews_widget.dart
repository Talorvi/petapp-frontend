import 'package:flutter/material.dart';
import '../models/user.dart';

class ReviewsWidget extends StatelessWidget {
  final User user;

  const ReviewsWidget({Key? key, required this.user}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Replace with your actual reviews widget implementation
    return Center(
      child: Text('Reviews for ${user.name}'),
    );
  }
}